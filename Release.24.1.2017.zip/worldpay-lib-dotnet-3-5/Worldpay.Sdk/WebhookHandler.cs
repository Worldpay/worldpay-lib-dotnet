﻿namespace Worldpay.Sdk
{
    public class WebhookHandler
    {
    }
}
