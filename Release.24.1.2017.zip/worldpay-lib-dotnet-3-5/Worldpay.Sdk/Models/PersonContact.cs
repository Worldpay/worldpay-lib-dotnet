﻿namespace Worldpay.Sdk.Models
{
    public class PersonContact : AbstractPerson
    {
        public string email { get; set; }

        public string phone { get; set; }
    }
}
