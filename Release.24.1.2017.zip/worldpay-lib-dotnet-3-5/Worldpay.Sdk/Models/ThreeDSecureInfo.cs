﻿namespace Worldpay.Sdk.Models
{
    public class ThreeDSecureInfo
    {
        public string shopperIpAddress { get; set; }

        public string shopperSessionId { get; set; }

        public string shopperAcceptHeader { get; set; }

        public string shopperUserAgent { get; set; }
    }
}
