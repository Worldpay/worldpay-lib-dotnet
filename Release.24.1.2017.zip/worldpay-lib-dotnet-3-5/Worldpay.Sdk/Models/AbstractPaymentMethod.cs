﻿namespace Worldpay.Sdk.Models
{
    abstract public class AbstractPaymentMethod
    {
        public string type { get; set; }
    }
}
