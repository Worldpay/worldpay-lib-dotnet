﻿namespace Worldpay.Sdk.Models
{
    public class MerchantOrderSetting
    {
        public string optInForRecurringBilling { get; set; }
    }
}
