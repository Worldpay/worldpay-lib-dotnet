﻿namespace Worldpay.Sdk.Models
{
    public class BaseMerchant
    {
        public string aggregateMerchantId { get; set; }
    }
}
