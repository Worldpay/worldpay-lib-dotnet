﻿
namespace WorldPay.Sdk.Models
{
    public class CaptureRequest
    {
        public int captureAmount { get; set; }
    }
}
