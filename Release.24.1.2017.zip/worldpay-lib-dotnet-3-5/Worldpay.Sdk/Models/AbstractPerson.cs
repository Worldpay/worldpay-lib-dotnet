﻿namespace Worldpay.Sdk.Models
{
    abstract public class AbstractPerson
    {
        public Name name { get; set; }
    }
}
