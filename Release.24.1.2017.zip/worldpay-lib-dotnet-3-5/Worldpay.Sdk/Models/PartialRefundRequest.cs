﻿namespace WorldPay.Sdk.Models
{
    class PartialRefundRequest
    {
        public int refundAmount { get; set; }
    }
}
