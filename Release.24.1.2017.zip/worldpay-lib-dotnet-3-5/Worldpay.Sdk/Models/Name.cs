﻿namespace Worldpay.Sdk.Models
{
    public class Name
    {
        public string title { get; set; }

        public string firstName { get; set; }

        public string middleName { get; set; }

        public string lastName { get; set; }
    }
}
