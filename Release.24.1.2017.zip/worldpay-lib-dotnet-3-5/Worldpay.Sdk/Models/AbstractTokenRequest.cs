﻿namespace Worldpay.Sdk.Models
{
    abstract public class AbstractTokenRequest
    {
        public string clientKey { get; set; }
    }
}
