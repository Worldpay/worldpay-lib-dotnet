﻿namespace Worldpay.Sdk.Enums
{
    public enum OrderType
    {
        ECOM,
        RECURRING,
        MOTO,
        APM
    }
}
