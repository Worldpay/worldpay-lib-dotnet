﻿namespace Worldpay.Sdk.Enums
{
    public enum Environment
    {    
        TEST, 
        LIVE
    }
}
