﻿namespace Worldpay.Sdk.Enums
{
    public enum RequestMethod
    {
        Delete,
        Get,
        Post,
        Put
    }
}
